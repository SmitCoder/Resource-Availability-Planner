import React from "react";
import Nav from "./components/Nav";
import { Routes, Route } from "react-router-dom";
import Sidebar from "./components/Sidebar";
import GenerateCalendar from "./components/GenerateCalendar";

const App = () => {
  return (
    <>
      <Sidebar />
      <Nav />

      <Routes>
        <Route path="" element={<GenerateCalendar />} />
      </Routes>
    </>
  );
};

export default App;

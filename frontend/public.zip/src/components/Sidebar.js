import { useState } from "react";
import DropdownsWithCheckboxes from "./DropdownsWithCheckboxes";

import "../Css/Sidebar.css";

const Sidebar = () => {
  const [show, setShow] = useState(false);

  const toggleSidebar = () => {
    setShow(!show);
  };

  return (
    <div className={`sidebar-container ${show ? "active" : ""}`}>
      <div className="bars" onClick={toggleSidebar}>
        {/* <button><i className={fa-2xl fa-solid fa-${show ? "xmark" : "bars"}}></i></button> */}
        <i
          className={`fa-lg fa-solid fa-angles-${show ? "left" : "right"}`}
        ></i>
      </div>

      <div className="sidebar">
        <DropdownsWithCheckboxes />
      </div>
    </div>
  );
};

export default Sidebar;

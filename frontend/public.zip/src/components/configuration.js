export const codes = [
  {
    leavetype: {
      name: "WH",
      color: "#005591",
    },
  },
  {
    leavetype: {
      name: "PL",
      color: "#CC0A0A",
    },
  },
  {
    leavetype: {
      name: "CL",
      color: "#CC0A0A",
    },
  },
  {
    leavetype: {
      name: "OL",
      color: "#CC0A0A",
    },
  },
  {
    leavetype: {
      name: "LP",
      color: "pink",
    },
  },
  {
    leavetype: {
      name: "SL",
      color: "#CC0A0A",
    },
  },
  {
    leavetype: {
      name: "WO",
      color: "#fdf2e0",
    },
  },
];
export const HD = "#F78900";

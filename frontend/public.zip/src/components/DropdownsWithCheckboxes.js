import React, { useState } from "react";
import { Multiselect } from "multiselect-react-dropdown";

function DropdownsWithCheckboxes() {
  // multiselect data
  const data = [
    { Department: "HR", id: 1 },
    { Department: "ITE", id: 2 },
    { Department: "GITAS", id: 3 },
  ];

  const data2 = [
    { Project: "xyz", id: 1 },
    { Project: "abc", id: 2 },
    { Project: "efg", id: 3 },
  ];

  const data3 = [
    { Team: "1", id: 1 },
    { Team: "2", id: 2 },
    { Team: "3", id: 3 },
  ];

  const [Dept_option] = useState(data);
  const [Pro_option] = useState(data2);
  const [Team_option] = useState(data3);
  return (
    <div>
      {/* multiselect data */}
      <div>
        <h6>Multiselect Dropdown</h6>
        <Multiselect options={Dept_option} displayValue="Department" />
        <Multiselect options={Pro_option} displayValue="Project" />
        <Multiselect options={Team_option} displayValue="Team" />
      </div>
    </div>
  );
}

export default DropdownsWithCheckboxes;

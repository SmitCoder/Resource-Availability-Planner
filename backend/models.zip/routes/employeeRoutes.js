const express = require("express");
const router = express.Router();
const employeeController = require("../controllers/employeeController");

// Get all employees
router.get("/names", employeeController.getAllEmployees);

// router.post("/", employeeController.getAllEmployees);

module.exports = router;

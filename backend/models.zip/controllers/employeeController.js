const Employee = require("../models/employee");

// Get all employees
exports.getAllEmployees = async (req, res) => {
  try {
    const employees = await Employee.find({});

    // const formattedEmployees = employees.map((employee) => ({
    //   name: employee.name,
    // }));
    // const sdf = console.log(employees);

    res.json(employees);
    console.log(employees);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
// // get sick leave

// const { MongoClient } = require("mongodb");

// const client = new MongoClient("mongodb://localhost:27017/LMS", {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// });

// async function connectToMongoDB() {
//   try {
//     await client.connect();
//     console.log("Connected to MongoDB");
//   } catch (error) {
//     console.error("Error connecting to MongoDB:", error);
//   }
// }
// connectToMongoDB();

// // Get all employees
// exports.getAllEmployees = async (req, res) => {
//   try {
//     const fromDate = req.body.startDate;
//     const toDate = req.body.endDate;
//     console.log(fromDate);

//     const startDate = new Date(fromDate);
//     const endDate = new Date(toDate);
//     endDate.setMonth(endDate.getMonth() + 1); // Move to the next month

//     const leaveData = await consolidateLeaves(startDate, endDate);

//     // console.log(leaveData);
//     res.json(leaveData);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };

// async function consolidateLeaves(startDate, endDate) {
//   const db = client.db("LMS");
//   const tempCollection = db.collection("tempLeaves");

//   const cursor = tempCollection.aggregate([
//     {
//       $match: {
//         fromDate: { $gte: startDate, $lte: endDate },
//       },
//     },
//     {
//       $group: {
//         _id: "$name",
//         leaveDates: {
//           $addToSet: {
//             fromDate: "$fromDate",
//             toDate: "$toDate",
//             leaveType: "$leaveType",
//           },
//         },
//       },
//     },
//     {
//       $project: {
//         _id: 0,
//         name: "$_id",
//         leaveDates: 1,
//       },
//     },
//   ]);

//   const consolidatedLeaves = await cursor.toArray();

//   const formattedLeaves = consolidatedLeaves.map((entry) => ({
//     name: entry.name,
//     leaveDates: entry.leaveDates.map((dateObj) => ({
//       fromDate: new Date(dateObj.fromDate).toISOString(),
//       toDate: new Date(dateObj.toDate).toISOString(),
//       leaveType: dateObj.leaveType,
//     })),
//   }));

//   console.log(formattedLeaves);

//   return formattedLeaves;
// }

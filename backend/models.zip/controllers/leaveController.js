const Leave = require("../models/Leave");

exports.getLeavesByDateRange = async (req, res) => {
  const { startDate, endDate } = req.query;

  try {
    const leaves = await Leave.find({
      leaveFrom: { $gte: startDate },
      leaveTo: { $lte: endDate },
    });
    res.json(leaves);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
